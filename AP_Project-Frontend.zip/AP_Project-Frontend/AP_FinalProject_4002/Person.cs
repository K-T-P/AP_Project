﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace AP_FinalProject_4002
{
    class Person
    {
        protected string FirstName { get; set; }
        protected string LastName { get; set; }
        protected string Email { get; set; }
        protected string Password { get; set; }
        protected string PhoneNum { get; set; }
        public static bool FirstNameCheck(string fName)
        {
            string pattern = @"^[a-zA-Z]{3,32}$";
            Regex rx = new Regex(pattern);
            Match m = rx.Match(fName);
            if (m.Success)
                return true;
            else
                return false;
        }
        public static bool LastNameCheck(string lName)
        {
            string pattern = @"^[a-zA-Z]{3,32}$";
            Regex rx = new Regex(pattern);
            Match m = rx.Match(lName);
            if (m.Success)
                return true;
            else
                return false;
        }

    }
}
