﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AP_FinalProject_4002
{
    /// <summary>
    /// Interaction logic for UserSignUp_Win1.xaml
    /// </summary>
    public partial class UserSignUp_Win1 : Window
    {
        public UserSignUp_Win1()
        {
            InitializeComponent();
        }
        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            StartUpWin prevWin = new StartUpWin();
            prevWin.Show();
            this.Close();
        }

        private void UserSignUpNextBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string firstName = FristnameTxtBx.Text;
                if (!User.FirstNameCheck(firstName))
                    throw new FormatException("First Name must have at least 3 characters and 32 characters at most.\nOnly English letters are allowed!" +
                        "\nSpace is not allowed!");
                string lastName = LastnameTxtBx.Text;
                if(!User.LastNameCheck(lastName))
                    throw new FormatException("Last Name must have at least 3 characters and 32 characters at most.\nOnly English letters are allowed!" +
                        "\nSpace is not allowed!");
                string phoneNumber = PhoneNumTxtBx.Text;
                if(!User.SignUp_PhoneNumberCheck(phoneNumber))
                    throw new FormatException("Phone Number initial digits must be 09 and must have 11 digits!");
                UserSignUp_Win2 nextSignUp = new UserSignUp_Win2(firstName,lastName,phoneNumber);
                nextSignUp.Show();
                this.Close();
            }
            catch(FormatException err)
            {
                MessageBox.Show(err.Message);
            }
            catch (OutOfMemoryException)
            {
                MessageBox.Show("Not enough memory on the device!");
            }
        }
    }
}
