﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AP_FinalProject_4002
{
    /// <summary>
    /// Interaction logic for UserSignUp_Win2.xaml
    /// </summary>
    public partial class UserSignUp_Win2 : Window
    {
        string firstName;
        string lasName;
        string phoneNumber;
        public UserSignUp_Win2(string fName, string lName, string phoneNumber)
        {
            this.firstName = fName;
            this.lasName = lName;
            this.phoneNumber = phoneNumber;
            InitializeComponent();
        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            UserSignUp_Win1 prevSignUp = new UserSignUp_Win1();
            prevSignUp.Show();
            this.Close();
        }

        private void FinalUserSignUpNextBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string email = EmailTxtBx.Text;
                if (!User.SignUp_EmailFormatCheck(email))
                    throw new FormatException("Email Format must be x@y.z in which x,y and z can only be English characters, digits and underscore!\n" +
                        "Each x,y and z must be at least 3 characters and 32, at most!");
                if (!User.SignUp_EmailExistsCheck(email))
                    throw new FormatException("This email is used!");
                string password = PassBx.Password;
                if(!User.SignUp_PasswordFormatCheck(password))
                    throw new FormatException("Password must be at least 8 characters and 40 characters at most!\nAnd must contain a lower case and an uppercase English" +
                        " character!");
                if (password != RptPassBx.Password)
                    throw new FormatException("Entered password and repeated password are not equal!");
                User newUser = new User(firstName,lasName,email,password,phoneNumber);
                User.userGrp.Add(newUser);
            //    User.users.Add(email,password);
                UserLogin_Win newLogin = new UserLogin_Win();
                newLogin.Show();
                this.Close();
            }
            catch(FormatException error)
            {
                MessageBox.Show(error.Message);
            }
            catch (OutOfMemoryException)
            {
                MessageBox.Show("Not enough memory on the device!");
            }
        }
    }
}
