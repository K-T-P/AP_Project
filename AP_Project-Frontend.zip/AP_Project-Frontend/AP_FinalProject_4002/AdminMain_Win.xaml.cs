﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AP_FinalProject_4002
{
    /// <summary>
    /// Interaction logic for AdminMain_Win.xaml
    /// </summary>
    public partial class AdminMain_Win : Window
    {
        string email;
        public AdminMain_Win(string email)
        {
            this.email = email;
            InitializeComponent();
        }

        private void MainBtn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BooksLstBtn_Click(object sender, RoutedEventArgs e)
        {
            tabtest.SelectedItem = BooksLstTb;
        }

        private void UsersLstBtn_Click(object sender, RoutedEventArgs e)
        {
            tabtest.SelectedItem = UsersLstTb;
            UserInfo_Win userinfo = new UserInfo_Win();
            userinfo.Show();
        }
    }
}
