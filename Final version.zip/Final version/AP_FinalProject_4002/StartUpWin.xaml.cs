﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AP_FinalProject_4002
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class StartUpWin : Window
    {
        public StartUpWin()
        {

            InitializeComponent();
            try
            {
                DateTime dateTime = new DateTime(2003,11,3);
            PDFBooks pDFBook = new PDFBooks("AP4002Project","koroush","taghiPour","iranian",dateTime,Gender.male,"","This is AP final project",@"PDFBooksPDF_Files\AP_4002_PROJECT.pdf", @"Pictures\APProjectPicture.jpg",Type.casual,1200,2,2000,0,3,0,0,DateTime.Now);
            PDFBooks.AddBookToGallery(pDFBook);
            AudioBooks audioBook = new AudioBooks("Wind","Unnoun","Unnoun","Unnoun",DateTime.Now,Gender.male,"","", @"AudioBooks\Wind.mp3",@"Pictures\Wind.jpg",Type.casual,0,5,2000,0,3,0,0,DateTime.Now);
            AudioBooks.AudioBooksList.Add(audioBook);
            Admin admin = new Admin("Koroush","TaghiPour","koroush@gmail.com","aA123456789","09912328375");
            Admin.adminGrp.Add(admin);
            User user = new User("farzan","mosayyebi","farzan@gmail.com","aA123456789","09123456789");
            User.userGrp.Add(user);
            PDFBooks.AutoSave();
            AudioBooks.AutoSave();
            Admin.AutoSave();
            User.AutoSave();
            PDFBooks.AutoLoad();
            AudioBooks.AutoLoad();
            Admin.AutoLoad();
            User.AutoLoad();

        }
            catch
            {

            }
        }

        private void UserLoginBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var newWin = new UserLogin_Win();
                newWin.Show();
                this.Close();
            }
            catch
            {

            }
        }

        private void UserSignUpBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                UserSignUp_Win1 newSignUp = new UserSignUp_Win1();
                newSignUp.Show();
                this.Close();
            }
            catch
            {

            }
        }

        private void AdminLoginBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                AdminLogin_Win newAdminLogin = new AdminLogin_Win();
                newAdminLogin.Show();
                this.Close();
            }
            catch
            {

            }
        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
