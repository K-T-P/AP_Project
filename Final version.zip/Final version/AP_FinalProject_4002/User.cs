﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
//using Microsoft.Data.SqlClient;
using System.IO;
using System.Collections.ObjectModel;

namespace AP_FinalProject_4002
{
    public class User : Person
    {
        static public Dictionary<string, string> users { get; set; } = new Dictionary<string, string>();

        static public ObservableCollection<User> userGrp { get; set; } = new ObservableCollection<User>();

        public ObservableCollection<PDFBooks> purchasedPDFBooks = new ObservableCollection<PDFBooks>();

        public ObservableCollection<PDFBooks> bookmarkedPDFBooks = new ObservableCollection<PDFBooks>();

        public ObservableCollection<PDFBooks> PDFBooksInCart = new ObservableCollection<PDFBooks>();

        public ObservableCollection<AudioBooks> purchasedAudioBooks = new ObservableCollection<AudioBooks>();

        public ObservableCollection<AudioBooks> bookmarkedAudioBooks = new ObservableCollection<AudioBooks>();

        public ObservableCollection<AudioBooks> AudioBooksInCart = new ObservableCollection<AudioBooks>();
        public long Balance { get; set; }

        public User(string fname, string lname, string email, string password, string phone)
        {
            FirstName = fname;
            LastName = lname;
            Email = email;
            Password = password;
            PhoneNum = phone;
            try
            {
                users.Add(Email, Password);
            }
            catch
            {

            }
            userGrp.Add(this);
        }


        public static void AutoLoad()
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" + AppDomain.CurrentDomain.BaseDirectory.ToString() + @"UserServer\UserServer.mdf;Integrated Security=True;Connect Timeout=30");
                string command = "select * from [UserTable]";
                try
                {
                    SqlCommand com = new SqlCommand(command, con);
                    con.Open();
                    SqlDataReader reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        try
                        {
                            string fName = reader["firstName"].ToString();
                            string lName = reader["lastName"].ToString();
                            string email = reader["email"].ToString();
                            string password = reader["password"].ToString();
                            string phoneNumber = reader["phoneNumber"].ToString();
                            string[] purchasedAudioBooks = reader["purchasedAudioBooks"].ToString().Split('a');
                            string[] purchaasedPDFBooks = reader["purchasedPDFBooks"].ToString().Split('a');
                            string[] bookmarkedAudioBooks = reader["bookmarkedAudioBooks"].ToString().Split('a');
                            string[] bookmarkedPDFBooks = reader["bookmarkedPDFBooks"].ToString().Split('a');
                            string[] PDFBooksInCart = reader["cartPDFBooks"].ToString().Split('a');
                            string[] AudioBooksInCart = reader["cartAudioBooks"].ToString().Split('a');
                            User newUser = new User(fName, lName, email, password, phoneNumber);
                            userGrp.Add(newUser);

                            if (purchasedAudioBooks[0] != "-1")
                            {
                                foreach (string id in purchasedAudioBooks)
                                {
                                    try
                                    {
                                        AudioBooks audioBook = null;
                                        var a = AudioBooks.AudioBooksList.Where(x => x._ID == int.Parse(id));
                                        foreach (var b in a)
                                            audioBook = b as AudioBooks;
                                        if (audioBook != null)
                                            newUser.purchasedAudioBooks.Add(audioBook);
                                    }
                                    catch
                                    {

                                    }
                                }
                            }
                            if (purchaasedPDFBooks[0] != "-1")
                            {
                                foreach (string id in purchaasedPDFBooks)
                                {
                                    try
                                    {
                                        PDFBooks pdfBook = null;
                                        var a = PDFBooks.pdfBookList.Where(x => x._ID == int.Parse(id));
                                        foreach (var b in a)
                                            pdfBook = b as PDFBooks;
                                        if (pdfBook != null)
                                            newUser.purchasedPDFBooks.Add(pdfBook);
                                    }
                                    catch
                                    {

                                    }
                                }
                            }
                            if (bookmarkedAudioBooks[0] != "-1")
                            {
                                foreach (string id in bookmarkedAudioBooks)
                                {
                                    try
                                    {
                                        AudioBooks audioBook = null;
                                        var a = AudioBooks.AudioBooksList.Where(x => x._ID == int.Parse(id));
                                        foreach (var b in a)
                                            audioBook = b as AudioBooks;
                                        if (audioBook != null)
                                            newUser.bookmarkedAudioBooks.Add(audioBook);
                                    }
                                    catch
                                    {

                                    }
                                }
                            }
                            if (bookmarkedPDFBooks[0] != "-1")
                            {
                                foreach (string id in bookmarkedPDFBooks)
                                {
                                    try
                                    {
                                        PDFBooks pdfBook = null;
                                        var a = PDFBooks.pdfBookList.Where(x => x._ID == int.Parse(id));
                                        foreach (var b in a)
                                            pdfBook = b as PDFBooks;
                                        if (pdfBook != null)
                                            newUser.bookmarkedPDFBooks.Add(pdfBook);
                                    }
                                    catch
                                    {

                                    }
                                }
                            }
                            if (AudioBooksInCart[0] != "-1")
                            {
                                foreach (string id in AudioBooksInCart)
                                {
                                    try
                                    {
                                        AudioBooks audioBook = null;
                                        var a = AudioBooks.AudioBooksList.Where(x => x._ID == int.Parse(id));
                                        foreach (var b in a)
                                            audioBook = b as AudioBooks;
                                        if (audioBook != null)
                                            newUser.AudioBooksInCart.Add(audioBook);
                                    }
                                    catch
                                    {

                                    }
                                }
                            }
                            if (PDFBooksInCart[0] != "-1")
                            {
                                foreach (string id in PDFBooksInCart)
                                {
                                    try
                                    {
                                        PDFBooks pdfBook = null;
                                        var a = PDFBooks.pdfBookList.Where(x => x._ID == int.Parse(id));
                                        foreach (var b in a)
                                            pdfBook = b as PDFBooks;
                                        if (pdfBook != null)
                                            newUser.PDFBooksInCart.Add(pdfBook);
                                    }
                                    catch
                                    {

                                    }
                                }
                            }
                            try
                            {
                                users.Add(email, password);
                            }
                            catch
                            {

                            }
                        }
                        catch
                        {

                        }
                    }
                    con.Close();
                    con = null;
                }
                catch
                {

                }
                finally
                {
                    if (con != null)
                        con.Close();
                }
            }
            catch
            {

            }
        }
        public static void AutoSave()
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" + AppDomain.CurrentDomain.BaseDirectory + @"UserServer\UserServer.mdf;Integrated Security=True;Connect Timeout=30");
                string command;
                try
                {
                    con.Open();
                    foreach (User user in User.userGrp)
                    {
                        try
                        {
                            string purchasedAudioBooksString = "";
                            try
                            {
                                if (user.purchasedAudioBooks.Count != 0)
                                {
                                    for (int i = 0; i < user.purchasedAudioBooks.Count - 1; i++)
                                    {
                                        try
                                        {
                                            if (user.purchasedAudioBooks[i] != null)
                                                purchasedAudioBooksString += (user.purchasedAudioBooks[i]._ID + 'a');
                                        }
                                        catch
                                        {

                                        }
                                    }
                                    purchasedAudioBooksString += user.purchasedAudioBooks[user.purchasedAudioBooks.Count - 1];
                                }
                                else
                                {
                                    purchasedAudioBooksString = "-1";
                                }
                            }
                            catch
                            {
                                purchasedAudioBooksString = "-1";
                            }

                            string purchasedPDFBooksString = "";
                            try
                            {
                                if (user.purchasedPDFBooks.Count != 0)
                                {
                                    for (int i = 0; i < user.purchasedPDFBooks.Count - 1; i++)
                                    {
                                        try
                                        {
                                            if (user.purchasedPDFBooks[i] != null)
                                                purchasedPDFBooksString += (user.purchasedPDFBooks[i]._ID + 'a');
                                        }
                                        catch
                                        {

                                        }
                                    }
                                    purchasedPDFBooksString += user.purchasedPDFBooks[user.purchasedPDFBooks.Count - 1];
                                }
                                else
                                {
                                    purchasedPDFBooksString = "-1";
                                }
                            }
                            catch
                            {
                                purchasedPDFBooksString = "-1";
                            }

                            string bookmarkedAudioBooksString = "";
                            try
                            {
                                if (user.bookmarkedAudioBooks.Count != 0)
                                {
                                    for (int i = 0; i < user.bookmarkedAudioBooks.Count - 1; i++)
                                    {
                                        try
                                        {
                                            if (user.bookmarkedAudioBooks[i] != null)
                                                bookmarkedAudioBooksString += (user.bookmarkedAudioBooks[i]._ID + 'a');
                                        }
                                        catch
                                        {

                                        }
                                    }
                                    bookmarkedAudioBooksString += user.bookmarkedAudioBooks[user.bookmarkedAudioBooks.Count - 1];
                                }
                                else
                                {
                                    bookmarkedAudioBooksString = "-1";
                                }
                            }
                            catch
                            {
                                bookmarkedAudioBooksString = "-1";
                            }

                            string bookmarkedPDFBooksString = "";
                            try
                            {
                                if (user.bookmarkedPDFBooks.Count != 0)
                                {
                                    for (int i = 0; i < user.bookmarkedPDFBooks.Count - 1; i++)
                                    {
                                        try
                                        {
                                            if (user.bookmarkedPDFBooks[i] != null)
                                                bookmarkedPDFBooksString += (user.bookmarkedPDFBooks[i]._ID + 'a');
                                        }
                                        catch
                                        {

                                        }
                                    }
                                    bookmarkedPDFBooksString += user.bookmarkedPDFBooks[user.bookmarkedPDFBooks.Count - 1];
                                }
                                else
                                {
                                    bookmarkedPDFBooksString = "-1";
                                }
                            }
                            catch
                            {
                                bookmarkedPDFBooksString = "-1";
                            }

                            string PDFBooksInCartString = "";
                            try
                            {
                                if (user.PDFBooksInCart.Count != 0)
                                {
                                    for (int i = 0; i < user.PDFBooksInCart.Count - 1; i++)
                                    {
                                        try
                                        {
                                            if (user.PDFBooksInCart[i] != null)
                                                PDFBooksInCartString += (user.PDFBooksInCart[i]._ID + 'a');
                                        }
                                        catch
                                        {

                                        }
                                    }
                                    PDFBooksInCartString += user.PDFBooksInCart[user.PDFBooksInCart.Count - 1];
                                }
                                else
                                {
                                    PDFBooksInCartString = "-1";
                                }
                            }
                            catch
                            {
                                PDFBooksInCartString = "-1";
                            }

                            string AudioBooksInCartString = "";
                            try
                            {
                                if (user.AudioBooksInCart.Count != 0)
                                {
                                    for (int i = 0; i < user.AudioBooksInCart.Count - 1; i++)
                                    {
                                        try
                                        {
                                            if (user.AudioBooksInCart[i] != null)
                                                AudioBooksInCartString += (user.AudioBooksInCart[i]._ID + 'a');
                                        }
                                        catch
                                        {

                                        }
                                    }
                                    AudioBooksInCartString += user.AudioBooksInCart[user.AudioBooksInCart.Count - 1];
                                }
                                else
                                {
                                    AudioBooksInCartString += "-1";
                                }
                            }
                            catch
                            {
                                AudioBooksInCartString += "-1";
                            }

                            command = "insert into [UserTable] values('" + user.Email.Trim() + "','" + user.FirstName + "','" +
                                user.LastName + "','" + user.PhoneNum + "','" + user.Password + "','" + purchasedAudioBooksString.Trim() + "','" + purchasedPDFBooksString.Trim() + "'" +
                                ",'" + bookmarkedAudioBooksString.Trim() + "','" + bookmarkedPDFBooksString.Trim() + "','" + PDFBooksInCartString.Trim() + "','" + AudioBooksInCartString.Trim() + "')";
                            SqlCommand com = new SqlCommand(command, con);
                            com.ExecuteNonQuery();
                        }
                        catch
                        {

                        }
                    }
                    con.Close();
                    con = null;
                }
                catch
                {

                }
                finally
                {
                    if (con != null)
                        con.Close();
                }
            }
            catch
            {

            }
        }
        public static bool LogIn_TrueEmailPasswordCheck(string email, string password)
        {
            try
            {
                var a = userGrp.Where(x => x.Email == email);
                User user = null;
                foreach (var varUser in a)
                {
                    try
                    {
                        user = (User)varUser;
                    }
                    catch
                    {

                    }
                }
                if (user.Password == password)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }
        public static User FindUser(string email)
        {
            try
            {
                var a = userGrp.Where(x => x.Email == email);
                User user = null;
                foreach (var instance in a)
                    user = instance;
                return user;
            }
            catch
            {
                return null;
            }
        }
        public static bool SignUp_EmailExistsCheck(string email)
        {
            try
            {
                foreach (string key in users.Keys)
                {
                    if (email.Equals(key))
                        return false;
                }
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool SignUp_PasswordFormatCheck(string password)
        {
            try
            {
                Regex rx = new Regex("^.{8,40}$");
                Match m = rx.Match(password);
                if (m.Success)
                {
                    rx = new Regex("(^.*[a-z].*[A-Z].*$)|(^.*[A-Z].*[a-z].*$)");
                    m = rx.Match(password);
                    if (m.Success)
                        return true;
                    else
                        return false;
                }
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }
        public static bool SignUp_PhoneNumberCheck(string phoneNumber)
        {
            try
            {
                string pattern = @"^09\d{9}$";
                Regex rx = new Regex(pattern);
                Match m = rx.Match(phoneNumber);
                if (m.Success)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }
        public static bool SignUp_EmailFormatCheck(string email)
        {
            try
            {
                string pattern = @"^\w{3,32}\@\w{3,32}\.\w{3,32}$";
                Regex rx = new Regex(pattern);
                Match m = rx.Match(email);
                if (m.Success)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }
        public static bool SignUp_fNameCheck(string fName)
        {
            try
            {
                string pattern = @"^[a-zA-Z]{3,32}$";
                Regex rx = new Regex(pattern);
                Match m = rx.Match(fName);
                if (m.Success)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }
        public static bool SignUp_lNameCheck(string lName)
        {
            try
            {
                string pattern = @"^[a-zA-Z]{3,32}$";
                Regex rx = new Regex(pattern);
                Match m = rx.Match(lName);
                if (m.Success)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }
        public static bool SignUp_EmailCheck(string email)
        {
            try
            {
                string pattern = @"^\w{3,32}\@\w{3,32}\.\w{3,32}$";
                Regex rx = new Regex(pattern);
                Match m = rx.Match(email);
                if (m.Success)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }

        public static bool CVVCheck(string CVV)
        {
            try
            {
                string pattern = @"^\d{3,4}$";
                Regex rx = new Regex(pattern);
                Match m = rx.Match(CVV);
                if (m.Success)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;            }        }
        public static bool CardNumber_Check(string cardNumber)
        {
            try
            {
                int num = 0;
                for (int i = cardNumber.Length - 1; i >= 0; i--)
                {
                    int a = (int)cardNumber[i] - 48;
                    if ((i + 1) % 2 == 0)
                        a *= 2;
                    if (a >= 10)
                        num += (a / 10 + a % 10);
                    else
                        num += a;
                }

                if (num % 10 == 0)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }
        public static bool CardExpirationDate_Check(string year, string month)
        {
            try
            {
                int yearInt = int.Parse(year);
                int monthInt = int.Parse(month);
                if (monthInt < 10)
                    yearInt += 621;
                else
                    yearInt += 622;
                monthInt = ((monthInt + 1) % 12) + 1;
                DateTime d1 = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 0);
                DateTime d2 = new DateTime(yearInt, monthInt, 0);
                int res = DateTime.Compare(d1, d2);
                if (res < 0)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }
        public static void WalletRecharge()
        {

        }

    }
}
